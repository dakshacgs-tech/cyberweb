<?php
// Backend database workflow only. This does NOT authenticate to ChatGPT or generate designs.
function ai_require_project(PDO $pdo, int $projectId, int $userId): array {
    $q=$pdo->prepare('SELECT * FROM projects WHERE id=? AND user_id=? LIMIT 1');
    $q->execute([$projectId,$userId]); $p=$q->fetch(PDO::FETCH_ASSOC);
    if (!$p) {http_response_code(404); exit('Project not found.');} return $p;
}
function ai_snapshot(PDO $pdo, int $projectId, int $userId): array {
    $p=ai_require_project($pdo,$projectId,$userId);
    $q=$pdo->prepare('SELECT hotel_name,phone,address,amenities,things_to_do FROM hotel_details WHERE project_id=? AND user_id=?');
    $q->execute([$projectId,$userId]); $hotel=$q->fetch(PDO::FETCH_ASSOC);
    if (!$hotel) throw new RuntimeException('Save Hotel Details before requesting designs.');
    $q=$pdo->prepare('SELECT faq_position,question,answer FROM hotel_faqs WHERE project_id=? AND user_id=? ORDER BY faq_position');
    $q->execute([$projectId,$userId]); $faqs=$q->fetchAll(PDO::FETCH_ASSOC);
    $q=$pdo->prepare('SELECT id,file_name FROM gallery_images WHERE project_id=? AND user_id=? ORDER BY id');
    $q->execute([$projectId,$userId]); $images=$q->fetchAll(PDO::FETCH_ASSOC);
    // Gallery images are references. Their bytes/logo must be delivered separately to the authorized executor.
    return ['project'=>['id'=>$projectId,'name'=>$p['name'],'team_member'=>$p['team_member'] ?? ''],
        'hotel'=>$hotel,'faqs'=>$faqs,'gallery'=>$images,
        'brand_colors'=>null,'logo_asset'=>null,
        'notice'=>'No dedicated logo or verified brand colors are stored in this schema. Supply them to your authorized design executor before color extraction.'];
}
function ai_create_request(PDO $pdo,int $projectId,int $userId):string {
    $input=ai_snapshot($pdo,$projectId,$userId);
    $prompt=file_get_contents(__DIR__.'/system_prompt.txt');
    if ($prompt===false) throw new RuntimeException('System prompt not available.');
    $id=bin2hex(random_bytes(16));
    $q=$pdo->prepare('INSERT INTO ai_generation_jobs(request_id,project_id,user_id,input_json,system_prompt) VALUES(?,?,?,?,?)');
    $q->execute([$id,$projectId,$userId,json_encode($input,JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR),$prompt]);
    return $id;
}
function ai_import_zip(PDO $pdo,int $jobId,int $projectId,int $userId,int $number,string $style,array $upload):void {
    if ($number<1||$number>4 || trim($style)==='' || mb_strlen($style)>90) throw new RuntimeException('Invalid design information.');
    if (($upload['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_OK || !is_uploaded_file($upload['tmp_name']??'')) throw new RuntimeException('Please upload a valid ZIP file.');
    if (($upload['size']??0)>25*1024*1024 || ($upload['size']??0)<100) throw new RuntimeException('ZIP size must be between 100 bytes and 25 MB.');
    $zip=new ZipArchive();
    if ($zip->open($upload['tmp_name'])!==true) throw new RuntimeException('Invalid ZIP archive.');
    $hasIndex=false;
    for($i=0;$i<$zip->numFiles;$i++) {
        $name=$zip->getNameIndex($i);
        if (!is_string($name) || str_contains($name,'..') || str_starts_with($name,'/') || str_contains($name,'\\')) { $zip->close();throw new RuntimeException('Unsafe archive path.'); }
        if ($name==='index.html') $hasIndex=true;
    }
    $zip->close();
    if (!$hasIndex) throw new RuntimeException('ZIP must contain index.html at the root.');
    $folder=__DIR__.'/../storage/ai_zips';
    if (!is_dir($folder) && !mkdir($folder,0700,true) && !is_dir($folder)) throw new RuntimeException('Archive storage unavailable.');
    $file=bin2hex(random_bytes(20)).'.zip'; $path=$folder.'/'.$file;
    if (!move_uploaded_file($upload['tmp_name'],$path)) throw new RuntimeException('Failed to store ZIP.');
    $hash=hash_file('sha256',$path);
    try {
        $q=$pdo->prepare('INSERT INTO ai_generated_designs(job_id,project_id,user_id,design_number,style_name,archive_name,sha256) VALUES(?,?,?,?,?,?,?)');
        $q->execute([$jobId,$projectId,$userId,$number,$style,$file,$hash]);
        $q=$pdo->prepare('SELECT COUNT(*) FROM ai_generated_designs WHERE job_id=? AND project_id=? AND user_id=?');
        $q->execute([$jobId,$projectId,$userId]);
        if ((int)$q->fetchColumn()===4) { $q=$pdo->prepare("UPDATE ai_generation_jobs SET status='completed',completed_at=NOW() WHERE id=? AND project_id=? AND user_id=?");$q->execute([$jobId,$projectId,$userId]); }
    } catch(Throwable $e) { @unlink($path); throw $e; }
}
function ai_select(PDO $pdo,int $projectId,int $userId,int $designId):void {
    $pdo->beginTransaction();
    try {
        $q=$pdo->prepare('SELECT id,job_id FROM ai_generated_designs WHERE id=? AND project_id=? AND user_id=? FOR UPDATE');
        $q->execute([$designId,$projectId,$userId]);$d=$q->fetch(PDO::FETCH_ASSOC);
        if(!$d)throw new RuntimeException('Design not found.');
        $q=$pdo->prepare("SELECT id FROM ai_generation_jobs WHERE id=? AND status='completed' AND project_id=? AND user_id=?");
        $q->execute([(int)$d['job_id'],$projectId,$userId]);if(!$q->fetchColumn())throw new RuntimeException('All four ZIP designs must be imported first.');
        $q=$pdo->prepare('UPDATE ai_generated_designs SET selected_at=NULL WHERE project_id=? AND user_id=?');$q->execute([$projectId,$userId]);
        $q=$pdo->prepare('UPDATE ai_generated_designs SET selected_at=NOW() WHERE id=? AND project_id=? AND user_id=?');$q->execute([$designId,$projectId,$userId]);
        $pdo->commit();
    } catch(Throwable $e) {if($pdo->inTransaction())$pdo->rollBack(); throw $e;}
}
